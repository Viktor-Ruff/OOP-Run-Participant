public interface Bouncing {

    void jump(Wall wall);
}
