public interface Running {

    void run(RunningTrack track);
}
