public interface Participant {

    int getRunLimit();

    double getJumpLimit();

    void jump();

    void run();
}
